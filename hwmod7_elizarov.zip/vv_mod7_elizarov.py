from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import argparse
import requests

# Обработка запросов
class ServiceHandler(BaseHTTPRequestHandler):
   # Устанавливаем параметры заголовков для ответа
   def set_headers(self):
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        length = int(self.headers["Content-Length"])
        content = self.rfile.read(length)
        temp = str(content).strip('b\'')
        self.end_headers()
        return temp

   #GET запросы, по условию задачи GET-запросы используются для сканирования сети
   def do_GET(self):
        i = 0
        def do_ping_sweep(ip, num_of_hosts):
            ip_parts = ip.split('.')
            network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
            scanned_ip = network_ip + str(int(ip_parts[3]) + int(num_of_hosts))
            response = os.popen(f'ping -n 1 -c 1 -w 2 {scanned_ip}')
            res = response.readlines()
            lost_pack = res[3].split(',')
            self.wfile.write((f"[#]\n Result of scanning: {scanned_ip} [#]\n{res[2]}{lost_pack[2]}").encode())
#Работа со значениями по умолчанию при направлении пустого запроса - не вышла, подскажите куда копать
#               if self.headers["Content-Length"] != None:
 #           temp = self.set_headers()
  #          tempdict = json.loads(temp) 
   #     else:
    #        temp = {
     #               "Target": "192.168.1.0",
      #              "count": "2"
#                }
#            tempdict = {"Target": "192.168.1.0","count": "2"}   

        temp = self.set_headers()
        tempdict = json.loads(temp) 
        for i in range(int(tempdict["count"])):
            do_ping_sweep(tempdict["Target"], str(i))


   # Обрабатываем POST запросы
   def do_POST(self):
        temp = self.set_headers()
        tempdict = json.loads(temp) 

        def sent_http_request(target, method, headers=None, payload=None):
            headers_dict = dict()
            if headers:
                for header in headers:
                    header_name = header.split(':')[0]
                    header_value = header.split(':')[1:]
                    headers_dict[header_name] = ':'.join(header_value)
            if method == "GET":
                response = requests.get(target, headers=headers_dict)
            elif method == "POST":
                response = requests.post(target, headers=headers_dict, data=payload)
            self.wfile.write((
                f"[#] Response status code: {response.status_code}\n"
                f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
                f"[#] Response content:\n {response.text}"
                ).encode())
        
        sent_http_request(tempdict["Target"], tempdict["Method"], tempdict["Header"], tempdict["Header-value"])


# Запускаем HTTP сервер
server = HTTPServer(('0.0.0.0', 8083), ServiceHandler)
server.serve_forever()